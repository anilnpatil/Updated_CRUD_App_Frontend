import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';
let _this: AddTableFormComponent
@Component({
  selector: 'app-add-table-form',
  templateUrl: './add-table-form.component.html',
  styleUrls: ['./add-table-form.component.scss']
})
export class AddTableFormComponent implements OnInit {
  tableForm: FormGroup = new FormGroup({
    tableName: new FormControl(''),
    columns: new FormArray([])
  });
  isSubmitted: boolean = false;
  dynamicTableCols = (this.tableForm.get('columns') as FormArray).controls

  constructor(private fb: FormBuilder, config: NgbDropdownConfig) {
    (this.tableForm.get('columns') as FormArray).controls;
    config.placement = 'bottom-right';
    // this.tableForm = this.fb.group({
    //   tablename: this.fb.control(''),
    //   fields: this.fb.array([]) // Initialize empty FormArray for dynamic fields
    // });
  }

  ngOnInit(): void {
  }
  addNewTable(isValid: boolean) {
    if (isValid) {
      alert('hey!')
    }
  }
  addNewField() {
    const control = this.fb.group({
      name: ['', Validators.required],
      dataType: ['', Validators.required],
      length: ['', Validators.required],
      primarykey: ['', Validators.required],
    });
    (this.tableForm.get('columns') as FormArray).push(control);
  }
  removeField(index: number) {
    (this.tableForm.get('columns') as FormArray).removeAt(index);
  }
  submitForm() {
    console.log(this.tableForm.value)
  }
}
export class createTableForm {
  tableName: string = "";
}