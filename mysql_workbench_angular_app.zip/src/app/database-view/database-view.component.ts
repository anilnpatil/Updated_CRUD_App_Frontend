import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpProviderService } from '../service/http-provider.service';
import { WebApiService } from '../service/web-api.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MODALS } from '../home/home.component';

@Component({
  selector: 'app-database-view',
  templateUrl: './database-view.component.html',
  styleUrls: ['./database-view.component.scss']
})
export class DatabaseViewComponent implements OnInit {

  databaseName: any;
  databaseDetail: any = [];

  constructor(public webApiService: WebApiService, private route: ActivatedRoute, private httpProvider: HttpProviderService, private modalService: NgbModal) { }

  ngOnInit(): void {
    this.databaseName = this.route.snapshot.queryParams['database'];
    this.getdatabaseDetailById();
  }

  getdatabaseDetailById() {
    this.httpProvider.getdatabaseDetailById(this.databaseName).subscribe((data: any) => {
      if (data != null && data.body != null) {
        var resultData = data.body;
        if (resultData) {
          this.databaseDetail = resultData;
        }
      }
    },
      (error: any) => { });
  }
  deleteTableConfirmation(tableId: any) {
    this.modalService.open(MODALS['deleteModal'],
      {
        ariaLabelledBy: 'modal-basic-title'
      }).result.then((result) => {
        alert(tableId + ' table deleted')
      },
        (reason) => { });
  }

}
