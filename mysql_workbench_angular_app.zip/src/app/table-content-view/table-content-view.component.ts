import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpProviderService } from '../service/http-provider.service';
import { WebApiService } from '../service/web-api.service';

@Component({
  selector: 'app-table-content-view',
  templateUrl: './table-content-view.component.html',
  styleUrls: ['./table-content-view.component.scss']
})
export class TableContentViewComponent implements OnInit {
  public queryParams = {};
  public tableData = [
    ['name', 'age', 'salary', 'number'],
    ['john', 29, '22500$', '9036']
  ];
  public tablecols = this.tableData.shift();
  constructor(public webApiService: WebApiService, private route: ActivatedRoute, private httpProvider: HttpProviderService) {
    this.queryParams = this.route.snapshot.queryParams;
  }

  ngOnInit(): void {
  }

}
