import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { WebApiService } from './web-api.service';

var apiUrl = "http://localhost:8080/";

// var apiUrl = "http://192.168.10.10:105";

var httpLink = {
  getAlldatabase: apiUrl + "/api/database/getAlldatabase",
  deletedatabaseById: apiUrl + "/api/database/deletedatabaseById",
  getdatabaseDetailById: apiUrl + "/api/database/getdatabaseDetailById",
  savedatabase: apiUrl + "/api/database/savedatabase"
}

@Injectable({
  providedIn: 'root'
})
export class HttpProviderService {

  constructor(private webApiService: WebApiService) { }

  public getAlldatabase(): Observable<any> {
    return this.webApiService.get(httpLink.getAlldatabase);
  }

  public deletedatabaseById(model: any): Observable<any> {
    return this.webApiService.post(httpLink.deletedatabaseById + '?databaseId=' + model, "");
  }

  public getdatabaseDetailById(model: any): Observable<any> {
    return this.webApiService.get(httpLink.getdatabaseDetailById + '?databaseId=' + model);
  }

  public savedatabase(model: any): Observable<any> {
    return this.webApiService.post(httpLink.savedatabase, model);
  }
}
