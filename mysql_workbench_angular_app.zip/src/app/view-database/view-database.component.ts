import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpProviderService } from '../service/http-provider.service';
import { WebApiService } from '../service/web-api.service';
import { MODALS } from '../home/home.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-view-database',
  templateUrl: './view-database.component.html',
  styleUrls: ['./view-database.component.scss']
})
export class ViewdatabaseComponent implements OnInit {

  databaseId: any;
  databaseDetail: any = [];

  constructor(public webApiService: WebApiService, private route: ActivatedRoute, private httpProvider: HttpProviderService,) { }

  ngOnInit(): void {
    this.databaseId = this.route.snapshot.params['database'];
    this.getdatabaseDetailById();
  }

  getdatabaseDetailById() {
    this.httpProvider.getdatabaseDetailById(this.databaseId).subscribe((data: any) => {
      if (data != null && data.body != null) {
        var resultData = data.body;
        if (resultData) {
          this.databaseDetail = resultData;
        }
      }
    },
      (error: any) => { });
  }


}
