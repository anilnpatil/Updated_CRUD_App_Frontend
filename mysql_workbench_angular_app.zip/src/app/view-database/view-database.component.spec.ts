import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewdatabaseComponent } from './view-database.component';

describe('ViewdatabaseComponent', () => {
  let component: ViewdatabaseComponent;
  let fixture: ComponentFixture<ViewdatabaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewdatabaseComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewdatabaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
